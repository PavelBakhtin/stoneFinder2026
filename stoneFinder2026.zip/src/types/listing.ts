export enum MaterialType {
  QUARTZ = "QUARTZ",
  NATURAL_STONE = "NATURAL_STONE",
  ACRYLIC = "ACRYLIC",
  CERAMIC = "CERAMIC",
  OTHER = "OTHER",
}

export enum ListingStatus {
  ACTIVE = "ACTIVE",
  RESERVED = "RESERVED",
  SOLD = "SOLD",
}
export enum ListingType {
  OFFER = "OFFER",
  WANTED = "WANTED",
}
export interface Listing {
  id: string;

  materialType: MaterialType;

  manufacturer: string | null;

  decor: string;

  length: number;

  width: number;

  thickness: number | null;

  city: string;

  phone: string;

  description?: string;

  images: string[];

  status: ListingStatus;

  createdAt: string;

  price: number | null;

  imageUrl: string | null;

  priceCurrency: string | null;

  listingType: ListingType;
}
